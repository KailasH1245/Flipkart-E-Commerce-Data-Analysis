-- 8. Top 3 Brands with Highest Revenue

SELECT TOP 3 p.Brand, SUM(sf.Total_Amount) AS Total_Revenue
FROM Sales_Fact sf
JOIN Products p ON sf.Product_ID = p.Product_ID
GROUP BY p.Brand
ORDER BY Total_Revenue DESC;
