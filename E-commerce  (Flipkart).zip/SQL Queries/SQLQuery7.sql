-- 7. Customer Segmentation by Age Group (Total Spend)

SELECT c.Age_Group, SUM(sf.Total_Amount) AS Total_Spend
FROM Sales_Fact sf
JOIN Customers c ON sf.Customer_ID = c.Customer_ID
GROUP BY c.Age_Group
ORDER BY Total_Spend DESC;
