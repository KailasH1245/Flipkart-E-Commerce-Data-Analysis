-- 5. Total Orders for Each Delivery Status

SELECT Delivery_Status, COUNT(Order_ID) AS Total_Orders
FROM Sales_Fact
GROUP BY Delivery_Status
ORDER BY Total_Orders DESC;
