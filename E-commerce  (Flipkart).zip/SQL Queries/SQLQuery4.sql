-- 4. Revenue Contribution by Payment Method

WITH PaymentRevenue AS (
    SELECT sf.Payment_Method, SUM(sf.Total_Amount) AS Total_Revenue
    FROM Sales_Fact sf
    GROUP BY sf.Payment_Method
)
SELECT * FROM PaymentRevenue
ORDER BY Total_Revenue DESC;
