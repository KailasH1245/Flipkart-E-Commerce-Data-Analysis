-- 9. Total Discounts Given by Category

SELECT p.Category, SUM(sf.Discount_Amount) AS Total_Discount
FROM Sales_Fact sf
JOIN Products p ON sf.Product_ID = p.Product_ID
GROUP BY p.Category
ORDER BY Total_Discount DESC;
