-- 2. Top 5 Cities with the Most Orders

SELECT TOP 5 c.City, COUNT(sf.Order_ID) AS Total_Orders
FROM Sales_fact sf
JOIN Customers c ON sf.Customer_ID = c.Customer_ID
GROUP BY c.City
ORDER BY Total_Orders DESC;