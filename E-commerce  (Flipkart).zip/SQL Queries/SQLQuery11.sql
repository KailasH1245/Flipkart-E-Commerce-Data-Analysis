-- 11. Top 5 Customers by Total Spend

SELECT TOP 5 c.Customer_Name, SUM(sf.Total_Amount) AS Total_Spend
FROM Sales_Fact sf
JOIN Customers c ON sf.Customer_ID = c.Customer_ID
GROUP BY c.Customer_Name
ORDER BY Total_Spend DESC;
