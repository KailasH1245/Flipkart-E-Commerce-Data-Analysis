-- 3. Average Order Rating by Seller


SELECT s.Seller_Name, AVG(sf.Review_Rating) AS Avg_Rating
FROM Sales_Fact sf
JOIN Sellers s ON sf.Seller_ID = s.Seller_ID
GROUP BY s.Seller_Name
ORDER BY Avg_Rating DESC;