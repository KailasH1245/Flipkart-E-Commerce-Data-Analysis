-- 12. Most Popular Product Subcategory by Quantity Sold

WITH SubcategorySales AS (
    SELECT p.Subcategory, SUM(sf.Quantity) AS Total_Quantity_Sold
    FROM Sales_Fact sf
    JOIN Products p ON sf.Product_ID = p.Product_ID
    GROUP BY p.Subcategory
)
SELECT * FROM SubcategorySales
ORDER BY Total_Quantity_Sold DESC;
