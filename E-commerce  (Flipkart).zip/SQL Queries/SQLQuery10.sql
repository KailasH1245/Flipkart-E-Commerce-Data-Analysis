-- 10. Average Shipping Cost by City

SELECT c.City, AVG(sf.Shipping_Cost) AS Avg_Shipping_Cost
FROM Sales_Fact sf
JOIN Customers c ON sf.Customer_ID = c.Customer_ID
GROUP BY c.City
ORDER BY Avg_Shipping_Cost DESC;