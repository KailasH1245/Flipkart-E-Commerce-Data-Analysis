-- 6. Top 5 Highest Selling Products (by Quantity)

SELECT  TOP 5 p.Product_Name, SUM(sf.Quantity) AS Total_Quantity_Sold
FROM Sales_Fact sf
JOIN Products p ON sf.Product_ID = p.Product_ID
GROUP BY p.Product_Name
ORDER BY Total_Quantity_Sold DESC;
